#
# testConversions.py - tests the functions in conversions.py
#
from conversions import *
print('\nTESTING CONVERSION -- fahr2cel\n')
testF = 'what you typed in'
testC = fahr2cel(testF)
print('Fahrenheit is', testF, 'Celsius is', testC)
print()

print('\nTESTING CONVERSIONS -- cel2fahr\n')
testCel = 'what you typed in'
testFahr = cel2fahr(testCel)
print('Celsius is', testCel, 'Fahrenheit is', testFahr)
print()



